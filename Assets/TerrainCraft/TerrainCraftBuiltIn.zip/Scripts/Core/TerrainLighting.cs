﻿using UnityEngine;
using System.Collections;
namespace TerrainCraft
{
    public class TerrainLighting : MonoBehaviour
    {

        public TerrainCraft terrain;


        private Material material;
        [SerializeField]
        private float shadowContrast = 100;
        [SerializeField]
        private Color defaultColor;
        [SerializeField]
        private Color lightColor = Color.white;
        [SerializeField]
        private Color shadowColor = Color.black;
        [SerializeField]
        private Texture2D texture;
        [SerializeField]
        private Projector lightProjector;
        void Start()
        {
            SetTexture();
        }
        public void Init()
        {
            CreateTexture();
            transform.localPosition = new Vector3(terrain.Width * 0.5f, 50, terrain.Height * 0.5f);

            SetTexture();
        }
        public void SetTexture()
        {


            //p.gameObject.hideFlags = HideFlags.HideInHierarchy;
            material = new Material(lightProjector.material);
            material.SetTexture("_ShadowTex", GetTexture());

            lightProjector.material = material;
            lightProjector.aspectRatio = (float)terrain.Width / (float)terrain.Height;
            lightProjector.orthographicSize = terrain.Height * 0.5f;


        }
        public void CreateTexture()
        {
            lightColor = Color.Lerp(Color.gray, Color.white, shadowContrast / 100);
            shadowColor = Color.Lerp(Color.gray, Color.black, shadowContrast / 100);
            defaultColor = Color.Lerp(shadowColor, lightColor, 0.5f);

            texture = new Texture2D(terrain.Width * 2, terrain.Height * 2);
            for (int y = 0; y < texture.height; y++)
            {
                for (int x = 0; x < texture.width; x++)
                {
                    texture.SetPixel(x, y, defaultColor);
                }
            }
            texture.Apply();

        }

        public void SetLighting(int x, int y, int pointValue, float ratio)
        {
            if (texture == null)
                return;
            int xx = x * 2;
            int yy = y * 2;

            switch (pointValue)
            {
                case 1:
                    yy++;
                    break;
                case 2:
                    xx++;
                    yy++;
                    break;
                case 3:
                    xx++;
                    break;
            }

            texture.SetPixel(xx, yy, Color.Lerp(shadowColor, lightColor, ratio));
        }
        public Texture2D GetTexture()
        {
            return texture;
        }
        public void Reset(int x, int y, int fieldValue)
        {
            if (texture == null)
                return;

            /*
            for(int a =0;a<2;a++)
                for(int b =0;b<2;b++)
                    texture.SetPixel (x+a, y+b, defaultColor);
    */

            float[] lightValues = new float[4] { 0.5f, 0.5f, 0.5f, 0.5f };

            switch (fieldValue)
            {

                case 1:
                    lightValues[0] = 0;
                    break;
                case 2:
                    lightValues[1] = 0.75f;
                    break;
                case 4:
                    lightValues[2] = 1;
                    break;
                case 8:
                    lightValues[3] = 0.25f;
                    break;

                case 3:
                    lightValues[2] = 0.25f;
                    lightValues[3] = 0.25f;
                    break;
                case 9:
                    lightValues[0] = 0.25f;
                    lightValues[3] = 0.25f;
                    break;
                case 6:
                    lightValues[1] = 0.75f;
                    lightValues[2] = 0.75f;
                    break;

                case 12:
                    lightValues[2] = 0.75f;
                    lightValues[3] = 0.75f;
                    break;

                case 5:
                    //diagonal
                    lightValues[1] = 0.5f;
                    lightValues[3] = 0.5f;
                    break;
                case 10:
                    //diagonal rotated
                    lightValues[2] = 0;
                    lightValues[0] = 1;
                    break;

                case 7:
                    lightValues[3] = 0.75f;
                    break;
                case 13:
                    lightValues[1] = 0.25f;
                    break;
                case 11:
                    lightValues[2] = 0;
                    break;
                case 14:
                    lightValues[0] = 1;
                    break;

                case 15:
                    break;
            }


            Set(terrain.Fields[x, y], lightValues);



        }

        public void Set(Field f, float[] lightValues)
        {
            float[] values = new float[4];

            for (int i = 0; i < 4; i++)
            {
                values[i] = f.heightValues[i];

            }

            float lightValue = (values[2] - values[0]) * 0.5f;

            if (lightValue > 0.45f)
                lightValue = 0.45f;
            if (lightValue < -0.45f)
                lightValue = -0.45f;

            lightValues[1] += lightValue;
            lightValues[2] += lightValue;
            lightValues[3] += lightValue;
            lightValues[0] += lightValue;




            for (int i = 0; i < 4; i++)
            {
                SetLighting(f.x, f.y, i, lightValues[i]);
            }


        }

        public void Apply()
        {
            texture.Apply(false, false);
        }
    }
}